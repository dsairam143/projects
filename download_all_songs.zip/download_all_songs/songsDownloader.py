'''
Created on 01-Mar-2018

@author: sairam

This script downloads only mp3 songs
you can modify this.
'''

from bs4 import BeautifulSoup
import re
import os
from urllib.parse import unquote
import urllib3
https = urllib3.PoolManager()

#Download Location
downloadLocation = 'C:\\Users\\sairam\\Desktop\\songs download\\'

#Give The Movie Name
folderName = "kabali"

#Check the folder exists or not.
if not os.path.isdir(downloadLocation+folderName):
    os.mkdir(downloadLocation+folderName)

#Enter website url here.
url = input("please enter site url:\n")
# "http://sensongsmp3.net/kabali-telugu-mp3-songs-e/"    
resp = https.request("GET",url)

jsoup = BeautifulSoup(resp.data, "html.parser")
links = jsoup.find_all("a", attrs={"href":re.compile('\.mp3',flags=re.IGNORECASE)})

#Loop all songs
for link in links:
    name = link['href']
    if '/' in name:
        name = re.sub('[^a-zA-Z0-9 ().]',' ',unquote(name[name.rindex('/')+1:]))
        print(name)
        path = downloadLocation+folderName+'\\'+name
    r = https.request('GET', link['href'], preload_content=False)

    #Find the length of a song
    print('file size =={:.2f} Mb'.format(int(r.headers.get('Content-Length'))/1024/1024))
    
    #Downloading the songs
    with open(path, 'wb') as out:
        while True:
            data = r.read(int(r.headers.get('Content-Length')))
            if not data:
                break
            out.write(data)
      
    r.release_conn()
    print('------------------------------------------------')
    
    
    