# import pyttsx3
# engine = pyttsx3.init()
# engine.say('The quick brown fox jumped over the lazy dog.')
# engine.runAndWait()

# import pytesseract
# a = pytesseract.image_to_string("C:\\Users\\sairam\\Desktop\\hw-np-01c.jpg")
# print(a)

