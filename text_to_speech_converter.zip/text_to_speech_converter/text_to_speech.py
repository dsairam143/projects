'''
Created on 04-Mar-2018

@author: sairam
'''
'''
Created on 01-Mar-2018

@author: sairam

This script downloads only mp3 songs
you can modify this.
'''

from bs4 import BeautifulSoup
import re
import os
from urllib.parse import unquote
import urllib3

import pyttsx3
engine = pyttsx3.init()
engine.setProperty('rate', 125)
engine.say('Welcome to songs downloader.Please enter song url and movie name')
engine.runAndWait()


https = urllib3.PoolManager()

#Download Location
downloadLocation = 'C:\\Users\\sairam\\Desktop\\songs download\\'

#Give The Movie Name
folderName = "kabali"

#Check the folder exists or not.
if not os.path.isdir(downloadLocation+folderName):
    os.mkdir(downloadLocation+folderName)

#Enter website url here.    
resp = https.request("GET","http://sensongsmp3.net/kabali-telugu-mp3-songs-e/")

jsoup = BeautifulSoup(resp.data, "html.parser")
links = jsoup.find_all("a", attrs={"href":re.compile('\.mp3',flags=re.IGNORECASE)})

for link in links:
    name = link['href']
    if '/' in name:
        name = re.sub('[^a-zA-Z0-9 ().]',' ',unquote(name[name.rindex('/')+1:]))
        print(name)
        path = downloadLocation+folderName+'\\'+name
    engine.say(f'{name} downloading please wait')
    engine.runAndWait()
    r = https.request('GET', link['href'], preload_content=False)
    # print(r)
    
    #Find the length of a song
    print('file size =={:.2f} Mb'.format(int(r.headers.get('Content-Length'))/1024/1024))
    engine.say('file size ={:.2f} Mb'.format(int(r.headers.get('Content-Length'))/1024/1024))
    engine.runAndWait()
    
    #Downloading the songs
    with open(path, 'wb') as out:
        while True:
            data = r.read(int(r.headers.get('Content-Length')))
            if not data:
                break
            out.write(data)
      
    r.release_conn()
    
    engine.say(f'{name} downloading completed...')
    engine.runAndWait()
    print('------------------------------------------------')
engine.stop()
    
