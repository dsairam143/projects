#-*- coding:utf-8 -*-
import requests
from textblob import TextBlob
from texttable import Texttable
t = Texttable()
t.header(["Author Name", "Status","Text"])
t.set_cols_width([20,10,150])
data = {"productId": "9789352603633",
        "count": "100",
        "ratings": "ALL",
        "reviewerType:ALL"
        "sortOrder": "MOST_HELPFUL"}



headers = ({"x-user-agent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.92 Safari/537.36 FKUA/website/41/website/Desktop"})
data = requests.get("https://www.flipkart.com/api/3/product/reviews", params=data, headers=headers).json()
# print(data)
resp = data["RESPONSE"]
results = resp["data"]
tweets = []

for result in results:
    author = result["value"]["author"]
    text = result["value"]["text"]
    
    analysis = TextBlob(text)
    # set sentiment
    if analysis.sentiment.polarity > 0:
        tweets.append([author,"positive",text])
    elif analysis.sentiment.polarity == 0:
        tweets.append([author,"neutral",text])
    else:
        tweets.append([author,"negative",text])


positiveTweets = [tweet for tweet in tweets if tweet[1] == 'positive']
print(f"Positive tweets percentage: {100*len(positiveTweets)/len(tweets)}% and {len(positiveTweets)} People are talking positive ")
# for pT in positiveTweets:
#     t.add_row(pT)


negativeTweets = [tweet for tweet in tweets if tweet[1] == 'negative']
print(f"Negative tweets percentage: {100*len(negativeTweets)/len(tweets)}% and {len(negativeTweets)} People are talking negative ")
# for nT in negativeTweets:
#     t.add_row(nT)

neutralTweets = [tweet for tweet in tweets if tweet[1] == 'neutral']
print(f"Neutral tweets percentage: {100*len(neutralTweets)/len(tweets)}% and {len(neutralTweets)} People are talking neutrally ")
for nT in neutralTweets:
    t.add_row(nT)

print()
print("################################# Result #################################")
print(t.draw())

