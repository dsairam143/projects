'''
Created on 01-Mar-2018

@author: sairam
'''
from PIL import Image
import io
import os


import requests
from bs4 import BeautifulSoup

#plaese change the path
downloadLocation = 'C:\\Users\\sairam\\Desktop\\sssss\\'
folderName = "images"
if not os.path.isdir(downloadLocation+folderName):
    os.mkdir(downloadLocation+folderName)
path = downloadLocation + folderName+'\\'+folderName

url = input("Please enter site url:\n")
resp = requests.get(url)
jsoup = BeautifulSoup(resp.text, "html.parser")
images = jsoup.find_all("img")
imageList = [image['src'] for image in images]
print(len(imageList))


for id, image in enumerate(imageList):
    try:
        if "?" in image:
            image = image[:image.index("?")]
        if "http" not in image:
            imageList.append("http:"+image)
            continue
        print(image)
        
        fd = requests.get(image)
        image_file = io.BytesIO(fd.content)
        im = Image.open(image_file)
        
        im.save(path+"-"+str(id)+".jpg")
        
    except Exception as e:
        print(e)
        
        