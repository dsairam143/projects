'''
Created on 22-Nov-2018

@author: sairam
'''
import requests
import re
from PIL import Image
import io
import MySQLdb
from beautifultable import BeautifulTable
table = BeautifulTable()
table.column_headers = ["Book Name", "Actual Price","Selling Rate", "lose Price"]
try:
    connection = MySQLdb.connect(user='root',password='sairam143sairam',port=3306,host='localhost')
except Exception as e:
    print(e)
else:
    
    downloadLocation = 'E:\\Repository\\RealTimeProjects\\download_all_images\\images\\'
    tutorialCursor = connection.cursor()
    tutorialCursor.execute("SELECT image_url, movie_name, movie_language FROM onemove.one_movie_data WHERE id < 280 ;")
    Images = tutorialCursor.fetchall()
    connection.close()
    for image in Images:
        try:
            print(image[0])
            print(image[1])
            name = image[1].strip().replace(' ','-').strip('-')+'-'+image[2]
            print(name)
            
            fd = requests.get(image[0])
            image_file = io.BytesIO(fd.content)
            im = Image.open(image_file)
              
            im.save(downloadLocation+name+".jpg")
        except Exception as e:
            print(e)
            