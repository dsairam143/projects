'''
Created on 08-Jan-2018

@author: sairam
'''

import requests
from bs4 import BeautifulSoup
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import io
import re
from multiprocessing import Process,Manager

import sys
resultList = []
headers = {
            "accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
            "user-agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36"
          }


#Infibeam Affiliate Method
def infibeamAffiliate(id,return_dict):
    infiList = {"affiliateName":"InfiBeam","title":'', "link":'', "author":'', "finalPrice":0, "maxPrice":0, "discount":0, "affImage":"infibeam_store.png", "found":False}
    dummyInfiList = infiList
    try:
        #infibeam Affiliate Search Url
        infiResp = requests.get( url="https://www.infibeam.com/search?q="+id+"&us=true")
    
        jsoup = BeautifulSoup(infiResp.content,"html.parser")
        jsoup = jsoup.find("div", attrs={"id":"resultPane"})
        if jsoup is not None:
            title = jsoup.find("div",attrs={"class":"title"})
            if title is not None:
                 
                anchor = title.find("a")
                if anchor is not None:
                    if anchor['href'] is not None:
                        link = anchor['href']
                        if "https://www.infibeam.com" not in link:
                            link = "https://www.infibeam.com"+link
                        infiList['link'] = link+"&trackId=dsairam" 
                
                price = jsoup.find("div",attrs={"class":"price row"})
                if price is not None:
                    finalPrice = price.find("span", attrs={"class":"final-price"})
                    if finalPrice is not None:
                        finalPrice = finalPrice.text
                        infiList['finalPrice'] = finalPrice
                if id not in link:
                    infiList = dummyInfiList
                    infiList['found'] = False
                else:
                    infiList['found'] = True
                    return_dict['infi']=infiList
                    
        else:
            infiList['found'] = False
    except:
        print(sys.exc_info())
    
#Sapna Affiliate Method
def sapnaAffiliate(id, return_dict):
    sapnaList = {"affiliateName":"SapnaOnline", "title":'', "link":'', "author":'', "finalPrice":0, "maxPrice":0, "discount":0, "affImage":"sapna_online_store.png", "found":False}
    dummySapnaList = sapnaList
    try:
        #Sapna Affiliate Search Url
        sapnaResp = requests.get(url="https://www.sapnaonline.com/general-search?searchkey="+id, timeout=10)
        jsoup = BeautifulSoup(sapnaResp.content, "html.parser")
        jsoup = jsoup.find("div", attrs={"class":"row no-margin"})
        title = jsoup.find("h2")
        if title is not None:
            anchor = title.find("a")
            if anchor is not None:
                link = anchor['href']
                sapnaList['link'] = link+"&affiliateID=SA-54B5460B"
            maxPrice = jsoup.find("span",attrs={"class":"actual-price"})
            if maxPrice is not None:
                maxPrice = maxPrice.text
                maxPrice = re.sub("[^0-9.]","",maxPrice)
                sapnaList['finalPrice'] = maxPrice 
            if id not in link[:link.index('?')]:
                sapnaList = dummySapnaList
                sapnaList['found'] = False
            else:
                sapnaList['found'] = True
                return_dict['sapna'] = sapnaList
            
        else:
            pass
    except:
        pass
    

#Reddif Affiliate Method
def reddifAffiliate(id, return_dict):
    reddimList = {"affiliateName":"Rediff","title":'', "link":'', "author":'', "finalPrice":0, "maxPrice":0, "discount":0, "affImage":"rediff_store.png", "found":False}
    dummyReddimList = reddimList
    try:
        #RediffMatcher Affiliate Search Url
        reddifResp = requests.get(url="http://books.rediff.com/search/"+id+"?output=xml&comscorekw=pageview_candidate&src=search_"+id, timeout=5)
    
        jsoup = str(BeautifulSoup(reddifResp.content, "html.parser"))
        try:
            jsoup = jsoup[jsoup.index("<querymatch>"):]
            jsoup = jsoup[:jsoup.index("</querymatch>")]
            
            
            if "<domesticwebprice><![CDATA[" in jsoup:
                finalPrice = jsoup[jsoup.index("<domesticwebprice><![CDATA[")+len("<domesticwebprice><![CDATA["):]
                finalPrice = finalPrice[:finalPrice.index("]]></domesticwebprice>")]
                reddimList['finalPrice'] = finalPrice
                
            if "<book_url><![CDATA[" in jsoup:
                bookUrl = jsoup[jsoup.index("<book_url><![CDATA[")+len("<book_url><![CDATA["):]
                bookUrl = bookUrl[:bookUrl.index("]]></book_url>")]
                reddimList['link'] = bookUrl
            if id not in bookUrl[:bookUrl.index("?")]:
                reddimList = dummyReddimList
                reddimList['found'] = False
            else:
                reddimList['found'] = True
                return_dict['reddif'] = reddimList
            
        except:
            pass
    except:
        pass
    

#Amazon Affiliate Method
def amazonAffiliate(id, return_dict):
    amzonList = {"affiliateName":"Amazon", "title":'', "link":'', "author":'', "finalPrice":0, "maxPrice":0, "discount":0, "affImage":"amazon_store.png", "found":False}
    dummyAmazonList = amzonList
    try:
        #Amazon Affiliate Search Url
        amazonResp = requests.get(url="https://www.amazon.in/s/ref=nb_sb_noss_2?url=search-alias%3Dstripbooks&field-keywords="+id,headers = headers, timeout=5)
        jsoup = BeautifulSoup(amazonResp.content, "html.parser")
        jsoup = jsoup.find("div",attrs={"class":"s-item-container"})
        
        anchor = jsoup.find("a", attrs={"class":"a-link-normal a-text-normal"})
        if anchor is not None:
            anchor = anchor["href"]
            amzonList['link'] = anchor+"&tag=dsairam-21"
        
        finalPrice = jsoup.find("span", attrs={"class":re.compile("s-price")})
        if finalPrice is not None:
            finalPrice = finalPrice.text.strip()
            amzonList['finalPrice'] = finalPrice
        if id not in anchor:
            amzonList = dummyAmazonList
            amzonList['found'] = False
        else:
            amzonList['found'] = True
            return_dict['amazon'] = amzonList
    except:
        pass
    

def flipkartMatcher(id, return_dict):
    flipkartList = {"affiliateName":"Flipkart", "title":'', "link":'', "author":'', "finalPrice":0, "maxPrice":0, "discount":0, "affImage":"flipkart_store.png", "found":False}
    infiResp = requests.get( url="https://www.flipkart.com/search?q="+id+"&otracker=start&as-show=off&as=off")
    jsoup = BeautifulSoup(infiResp.content,"html.parser")
    jsoup = jsoup.find("a",attrs={"class":"_1Vfi6u"})
    if jsoup is not None:
        flipkartList['found'] = True
        flipkartList['link'] = jsoup['href']+"&affid=sairamdod"
        if "https://www.flipkart.com" not in flipkartList['link']:
            flipkartList['link'] = "https://www.flipkart.com"+flipkartList['link']
        jsoup = jsoup.find("div", attrs={"class":"_1vC4OE"})
        if jsoup is not None:
            price = re.sub("[^0-9.]", "", jsoup.text).strip('.').strip(' ')
            flipkartList['finalPrice'] = price
            return_dict['flipkart'] = flipkartList
        

# Image Creation Method.
def affiliateImageCreator(Idata, imageUrl):
    
    #Download Image
    http = requests.get(url=imageUrl)
    im = io.BytesIO(http.content)
    
    
    #Get the size
    
    font = ImageFont.truetype('FreeMonoBold.ttf', 30)
    pixelGap = 20
    if len(Idata)*33>5*33:
        pixelGap = 15
    imageHeight = len(Idata) * 33 +len(Idata)*pixelGap
    
    buttonImage = Image.open("button.png")
    buttonWidth, buttonHeight = buttonImage.size
    
    #create affiliate image
    affiliateImagewidth = 300+buttonWidth
    affiliateImage = Image.new("RGB",(affiliateImagewidth+5,imageHeight+5+40),"#fff")
    # affiliateImage.show()
    
    offset = 0
    priceList = []
    for x,k in enumerate(Idata):
        img = Image.open(k[0])
        width, height = img.size
        #print(width,height)
        
        #Paste image on affiliate image
        affiliateImage.paste(img,(5, offset+5))
        draw = ImageDraw.Draw(affiliateImage)
        draw.text((150, offset+5),"Rs."+str(k[1])+"",(153,153,153),font=font)
        priceList.append(k[1])
        affiliateImage.paste(buttonImage,(300, offset+5))
        offset = height*(x+1)+pixelGap*(x+1)
    
    font = ImageFont.truetype('FreeMonoBold.ttf', 20)
    drwaWidth, drawHeight = affiliateImage.size
    ImageDraw.Draw(affiliateImage).rectangle((0,0,drwaWidth-5,drawHeight-44),outline=(255,0,0))
    draw = ImageDraw.Draw(affiliateImage)
    
    for pri in Idata:
        if pri[1] == min(priceList):
            miniAffiliate = pri[2]
    draw.text((0, drawHeight-40),"Best Price Rs."+str(min(priceList))+" at "+miniAffiliate+"",(153,153,153),font=font)
            
        
    #affiliateImage.show()
    
    # Get the size of the image
    width, height = affiliateImage.size
    
    # Process every pixel
    for x in range(0,width):
        for y in range(0,height):
            current_color = affiliateImage.getpixel( (x,y) )
    #         #print(current_color)
            if current_color == (71, 112, 76):
                current_color = (255, 255,255)
            affiliateImage.putpixel( (x,y), current_color)
    
    affiliateImage = affiliateImage.filter(ImageFilter.EDGE_ENHANCE_MORE)

    affwidth, affheight = affiliateImage.size
    
    im = Image.open(im)
    
    if pixelGap == 20:
        dumWidth = 250
        im = im.resize((dumWidth,400))
        subWidth, subHeight = im.size
        newImage = Image.new("RGB", (dumWidth+50+affiliateImagewidth,subHeight+20), "white")
        newImage.paste(im,(10,10))
        newImage.paste(affiliateImage,(subWidth+30,10))
        
        
        
    #     newImage.paste(affiliateImage,(subWidth+30,10))
        newImage.show(title="hello", command=None)
        newImage.save("C:\\Users\\sairam\\Desktop\\flipkartAdds\\payodhishopping.jpg")
    else:
        dumWidth = 300
        im = im.resize((dumWidth,affheight))
        subWidth, subHeight = im.size
        newImage = Image.new("RGB", (dumWidth+50+affiliateImagewidth,subHeight+20), "white")
        newImage.paste(im,(10,10))
        newImage.paste(affiliateImage,(subWidth+30,10))
        newImage.paste(affiliateImage,(subWidth+30,10))
        newImage.save("ou.jpg")
#         newImage.show()
        newImage.save("C:\\Users\\sairam\\Desktop\\flipkartAdds\\payodhishopping.jpg")


if __name__ == "__main__":
    import time
    manager = Manager()
    return_dict = manager.dict()
    start  = time.time()
    id = "9788126556434"
    imageUrl = "https://rukminim1.flixcart.com/image/832/832/book/4/3/4/professional-angularjs-original-imae94sfreyzsbep.jpeg?q=70"
    
    def runInParallel(*fns):
        proc = []
        for fn in fns:
            p = Process(target=fn, args=(id,return_dict,))
            p.start()
            proc.append(p)
        for p in proc:
            p.join()

    runInParallel(infibeamAffiliate, sapnaAffiliate, reddifAffiliate, amazonAffiliate, flipkartMatcher)

    
    imList=[]
    for res in return_dict.keys():
        print("Affiliate : ",return_dict[res]['affiliateName'])
        print("Price :Rs",int(re.sub("[^0-9.]","",return_dict[res]['finalPrice']).strip('.')))
        print("Link : ",return_dict[res]['link'])
        print("")
        print("")
        
        imList.append((return_dict[res]['affImage'], int(re.sub("[^0-9.]","",return_dict[res]['finalPrice']).strip('.')),return_dict[res]['affiliateName']))
    imList = sorted(imList, key=lambda x:x[1])
    affiliateImageCreator(imList, imageUrl)

    
    print(return_dict)
    print(time.time()-start)
    
    